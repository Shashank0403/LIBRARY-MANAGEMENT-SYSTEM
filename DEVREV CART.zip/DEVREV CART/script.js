document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const searchResults = document.getElementById('searchResults');
    const cartCount = document.getElementById('cartCount');
    const cartList = document.getElementById('cartList'); // Added a cart list element
    let cart = [];

    searchButton.addEventListener('click', function () {
        const searchText = searchInput.value.trim();
        if (searchText !== '') {
            searchBooks(searchText);
        }
    });

    searchInput.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
            const searchText = searchInput.value.trim();
            if (searchText !== '') {
                searchBooks(searchText);
            }
        }
    });

    function searchBooks(query) {
        searchResults.innerHTML = '';
        fetch(`http://openlibrary.org/search.json?q=${query}`)
            .then(response => response.json())
            .then(data => {
                const books = data.docs;
                if (books.length > 0) {
                    books.forEach(book => {
                        const bookDiv = document.createElement('div');
                        bookDiv.classList.add('book');
                        const title = document.createElement('h3');
                        title.textContent = book.title_suggest || 'N/A';
                        const author = document.createElement('p');
                        author.textContent = book.author_name ? `Author: ${book.author_name[0]}` : 'Author: N/A';
                        const publishedYear = document.createElement('p');
                        publishedYear.textContent = book.first_publish_year ? `Year: ${book.first_publish_year}` : 'Year: N/A';
                        const cover = document.createElement('img');
                        cover.src = `http://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` || 'https://via.placeholder.com/100x150';

                        const addToCartButton = document.createElement('button');
                        addToCartButton.textContent = 'Add to Cart';
                        addToCartButton.addEventListener('click', function () {
                            addToCart(book);
                            updateCartList(); // Update the cart list when a book is added
                        });

                        bookDiv.appendChild(cover);
                        bookDiv.appendChild(title);
                        bookDiv.appendChild(author);
                        bookDiv.appendChild(publishedYear);
                        bookDiv.appendChild(addToCartButton);
                        searchResults.appendChild(bookDiv);
                    });
                } else {
                    searchResults.textContent = 'No results found.';
                }
            })
            .catch(error => {
                console.error('Error fetching book data:', error);
                searchResults.textContent = 'An error occurred while fetching data.';
            });
    }

    function addToCart(book) {
        cart.push(book);
        updateCartCount();
    }

    function updateCartCount() {
        cartCount.textContent = cart.length;
    }

    function updateCartList() {
        cartList.innerHTML = '';
        cart.forEach(book => {
            const cartItem = document.createElement('div');
            cartItem.textContent = book.title_suggest || 'N/A';
            cartList.appendChild(cartItem);
        });
    }
});
